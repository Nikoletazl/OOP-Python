from project.fruit import Fruit

fruit = Fruit("Lemon", "2021-12-23")

print(fruit.name)
print(fruit.expiration_date)
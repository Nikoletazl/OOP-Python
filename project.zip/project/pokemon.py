class Pokemon():
    def __init__(self, name, healt):
        self.name = name
        self.health = healt

    def pokemon_details(self):
        return f"{self.name} with health {self.health}"